(function () {
  'use strict';

  document.getElementById('year').textContent = new Date().getFullYear();

  /* ---------------- NAV ---------------- */
  const header = document.getElementById('siteHeader');
  const navToggle = document.getElementById('navToggle');
  const navLinks = document.getElementById('navLinks');

  window.addEventListener('scroll', () => {
    header.classList.toggle('is-scrolled', window.scrollY > 40);
  }, { passive: true });

  navToggle.addEventListener('click', () => {
    const isOpen = navLinks.classList.toggle('is-open');
    navToggle.setAttribute('aria-expanded', String(isOpen));
    document.body.style.overflow = isOpen ? 'hidden' : '';
  });

  navLinks.querySelectorAll('a').forEach((a) => {
    a.addEventListener('click', () => {
      navLinks.classList.remove('is-open');
      navToggle.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
    });
  });

  /* ---------------- REVEAL ON SCROLL ---------------- */
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.15 });

  function observeReveal(el) {
    el.classList.add('reveal');
    revealObserver.observe(el);
  }
  document.querySelectorAll('.reveal').forEach(observeReveal);

  /* ---------------- PROFILE-DEPENDENT CONTENT ---------------- */
  function waLink(phoneDigits, message) {
    return `https://wa.me/${phoneDigits}?text=${encodeURIComponent(message)}`;
  }

  Api.getProfile().then((profile) => {
    // Floating WhatsApp button
    const waFloat = document.getElementById('whatsappFloat');
    waFloat.href = waLink(profile.whatsapp, `Hi ${profile.name}, I'd love to know more about your services.`);

    // Footer social links
    document.querySelectorAll('.footer-social a')[0].href = profile.instagramUrl;
    document.querySelectorAll('.footer-social a')[1].href = profile.facebookUrl;

    // Contact list
    const contactList = document.getElementById('contactList');
    contactList.innerHTML = `
      <li><span class="k">Phone</span><span class="v"><a href="tel:${profile.phone}">${profile.phoneDisplay}</a></span></li>
      <li><span class="k">WhatsApp</span><span class="v"><a href="${waLink(profile.whatsapp, `Hi ${profile.name}, I'd love to know more about your services.`)}" target="_blank" rel="noopener">Message on WhatsApp</a></span></li>
      <li><span class="k">Email</span><span class="v"><a href="mailto:${profile.email}">${profile.email}</a></span></li>
      <li><span class="k">Studio</span><span class="v">${profile.address}<br>${profile.city}</span></li>
      <li><span class="k">Instagram</span><span class="v"><a href="${profile.instagramUrl}" target="_blank" rel="noopener">@amitsharmamakeup</a></span></li>
    `;

    // Hours table
    const today = new Date().getDay();
    const hoursTable = document.getElementById('hoursTable');
    hoursTable.innerHTML = profile.businessHours.map((h, i) => `
      <tr class="${i === today ? 'is-today' : ''}">
        <td>${h.day}</td>
        <td>${h.closed ? 'Closed' : `${h.open} – ${h.close}`}</td>
      </tr>
    `).join('');
  });

  /* ---------------- SERVICES ---------------- */
  Api.getServices().then((services) => {
    const list = document.getElementById('servicesList');
    if (!services.length) {
      list.innerHTML = '<p class="list-empty">Services are being updated — please check back shortly.</p>';
      return;
    }
    list.innerHTML = services.map((s) => `
      <div class="service-row reveal">
        <div class="service-name">${s.name}</div>
        <div class="service-desc">${s.description}</div>
        <div class="service-meta">
          <div class="service-price">$${s.price}</div>
          <span class="service-duration">${s.duration} min</span>
        </div>
        <a href="book.html?service=${encodeURIComponent(s.id)}" class="btn btn-outline-dark">Book</a>
      </div>
    `).join('');
    list.querySelectorAll('.reveal').forEach(observeReveal);
  });

  /* ---------------- PORTFOLIO + LIGHTBOX ---------------- */
  const grid = document.getElementById('portfolioGrid');
  const filterBar = document.getElementById('filterBar');
  let currentItems = [];
  let lightboxIndex = 0;

  function renderPortfolio(items) {
    currentItems = items;
    if (!items.length) {
      grid.innerHTML = '<p class="portfolio-empty">No work in this category yet — check back soon.</p>';
      return;
    }
    grid.innerHTML = items.map((item, i) => `
      <button class="portfolio-item ${item.size ? 'size-' + item.size : ''} reveal" data-index="${i}" aria-label="View ${item.title} full screen">
        <img src="${item.imageUrl}" alt="${item.title} — ${item.category}" loading="lazy">
        <span class="portfolio-index">N°${String(i + 1).padStart(2, '0')}</span>
        ${item.isFeatured ? '<span class="portfolio-star" aria-hidden="true">&#10022;</span>' : ''}
        <span class="portfolio-caption">
          <span class="cat">${item.category}</span>
          <span class="title">${item.title}</span>
        </span>
      </button>
    `).join('');
    grid.querySelectorAll('.portfolio-item').forEach((btn) => {
      btn.addEventListener('click', () => openLightbox(Number(btn.dataset.index)));
      observeReveal(btn);
    });
  }

  function loadPortfolio(category) {
    grid.setAttribute('aria-busy', 'true');
    Api.getPortfolio({ category }).then((items) => {
      renderPortfolio(items);
      grid.setAttribute('aria-busy', 'false');
    });
  }

  filterBar.addEventListener('click', (e) => {
    const btn = e.target.closest('.filter-btn');
    if (!btn) return;
    filterBar.querySelectorAll('.filter-btn').forEach((b) => {
      b.classList.remove('is-active');
      b.setAttribute('aria-selected', 'false');
    });
    btn.classList.add('is-active');
    btn.setAttribute('aria-selected', 'true');
    loadPortfolio(btn.dataset.filter);
  });

  loadPortfolio('all');

  // Lightbox
  const lightbox = document.getElementById('lightbox');
  const lightboxImg = document.getElementById('lightboxImg');
  const lightboxCaption = document.getElementById('lightboxCaption');
  let lastFocusedEl = null;

  function openLightbox(index) {
    lightboxIndex = index;
    lastFocusedEl = document.activeElement;
    updateLightbox();
    lightbox.classList.add('is-open');
    document.body.style.overflow = 'hidden';
    document.getElementById('lightboxClose').focus();
  }
  function closeLightbox() {
    lightbox.classList.remove('is-open');
    document.body.style.overflow = '';
    if (lastFocusedEl) lastFocusedEl.focus();
  }
  function updateLightbox() {
    const item = currentItems[lightboxIndex];
    lightboxImg.src = item.imageUrl.replace('/800/', '/1400/').replace('/900/', '/1400/');
    lightboxImg.alt = `${item.title} — ${item.category}`;
    lightboxCaption.textContent = `${item.title} — ${item.caption}`;
  }
  document.getElementById('lightboxClose').addEventListener('click', closeLightbox);
  document.getElementById('lightboxPrev').addEventListener('click', () => {
    lightboxIndex = (lightboxIndex - 1 + currentItems.length) % currentItems.length;
    updateLightbox();
  });
  document.getElementById('lightboxNext').addEventListener('click', () => {
    lightboxIndex = (lightboxIndex + 1) % currentItems.length;
    updateLightbox();
  });
  lightbox.addEventListener('click', (e) => { if (e.target === lightbox) closeLightbox(); });
  document.addEventListener('keydown', (e) => {
    if (!lightbox.classList.contains('is-open')) return;
    if (e.key === 'Escape') closeLightbox();
    if (e.key === 'ArrowLeft') document.getElementById('lightboxPrev').click();
    if (e.key === 'ArrowRight') document.getElementById('lightboxNext').click();
  });

  /* ---------------- TESTIMONIALS ---------------- */
  const track = document.getElementById('testimonialTrack');
  Api.getTestimonials().then((items) => {
    if (!items.length) {
      track.innerHTML = '<p class="list-empty">Reviews are on their way.</p>';
      return;
    }
    track.innerHTML = items.map((t) => `
      <article class="testimonial-card">
        <div class="testimonial-rating" aria-label="${t.rating} out of 5 stars">${'★'.repeat(t.rating)}${'☆'.repeat(5 - t.rating)}</div>
        <p class="testimonial-quote">"${t.review}"</p>
        <div class="testimonial-person">
          <img src="${t.imageUrl}" alt="" loading="lazy">
          <div>
            <div class="name">${t.clientName}</div>
            <div class="occasion">${t.service}</div>
          </div>
        </div>
      </article>
    `).join('');
  });

  document.getElementById('testimonialPrev').addEventListener('click', () => {
    track.scrollBy({ left: -420, behavior: 'smooth' });
  });
  document.getElementById('testimonialNext').addEventListener('click', () => {
    track.scrollBy({ left: 420, behavior: 'smooth' });
  });
})();